"""`titan` command-line interface.

    titan env [--path DIR]              this environment's CPU/RAM/storage/GPUs and training limits
    titan prepare-data FILES --out X    byte-token corpus (memory-mapped, any size) for pretraining
    titan info [--arch dev]             architecture summary (analytical figures labelled as such)
    titan backends                      execution backends and their real availability
    titan quickstart [...]              one-command training on the virtual accelerator
    titan matmul --m --n --k            vertical slice: graph -> IR -> ISA -> execution -> verification
    titan bench [--suite quick]         reproducible benchmark report (verified / simulated / analytical / measured)
    titan tune --m --n --k              verified tiling search against the compiler baseline
    titan scale / dp-train              multi-device scaling study / data-parallel training
    titan rtl-verify                    RTL (Verilator) vs emulator bit-exact correspondence
    titan synth                         Yosys resource estimates (pre-place-and-route)
    titan asm FILE [--run]              assemble (and run) a TITAN assembly program
    titan disasm FILE                   disassemble a TITAN binary
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np

from .config import list_presets, load_config
from .dtypes import DType


def _print_kv(d: dict, indent: int = 2) -> None:
    w = max((len(k) for k in d), default=0)
    for k, v in d.items():
        print(" " * indent + f"{k:<{w}}  {v}")


# ------------------------------------------------------------------ info / backends

def cmd_info(a) -> int:
    cfg = load_config(a.arch)
    print(f"{cfg.name}  ({cfg.description})  config hash {cfg.config_hash()}")
    _print_kv({"cores": cfg.cores, "MXU per core": f"{cfg.mxu_rows}x{cfg.mxu_cols} PEs",
               "VPU / SFU lanes": f"{cfg.vpu_lanes} / {cfg.sfu_lanes}", "clock (assumed)": f"{cfg.clock_ghz} GHz",
               "LOCAL SRAM / core": f"{cfg.local_sram_kib} KiB ({cfg.gemm_staging_kib} KiB GEMM staging)",
               "SHARED SRAM": f"{cfg.shared_sram_kib} KiB", "L2": f"{cfg.l2_kib} KiB, {cfg.l2_ways}-way",
               "global memory": f"{cfg.global_mem_gib} GiB @ {cfg.hbm_gbps} GB/s (emulated: "
                                f"{cfg.emulated_global_mib} MiB)"})
    print("\nAnalytical dense peaks of this configuration (estimates, not measurements):")
    for dt in (DType.INT4, DType.INT8, DType.FP16, DType.BF16, DType.FP32):
        print(f"  {dt.name:5s} {cfg.peak_ops(dt) / 1e12:12.3f} TOPS   ridge point {cfg.ridge_point(dt):8.1f} ops/B")
    try:
        from .perf.reference import compare_peak
        print("\nPaper-peak comparison with NVIDIA B300 (same precision, dense, vendor/third-party figures):")
        for dt in (DType.BF16, DType.FP16):
            c = compare_peak(cfg, dt)
            print(f"  {dt.name:5s} TITAN {c['titan_peak_tflops']:.1f} TFLOPS vs B300 {c['b300_peak_tflops']:.1f} "
                  f"TFLOPS -> compute ratio {c['ratio']:.4g}x, memory-bandwidth ratio {c['bandwidth_ratio']:.3g}x")
        print(f"  ({c['label']}; memory-bound workloads scale with the bandwidth ratio, not the compute ratio)")
    except ImportError:
        pass
    return 0


def cmd_backends(a) -> int:
    from .runtime import backend_status
    print("TITAN execution backends:")
    for b, ok, why in backend_status():
        print(f"  [{'x' if ok else ' '}] {b.label:20s} {why}")
        print(f"      results are: {b.kind}")
    return 0


# ------------------------------------------------------------------ quickstart

def _ask(prompt: str, options: list[str], default: str) -> str:
    opts = "/".join(options)
    while True:
        r = input(f"{prompt} [{opts}] (default {default}): ").strip() or default
        if r in options:
            return r
        print(f"  please choose one of: {opts}")


def _quickstart_params(a) -> int | None:
    """--params N: train numerically if it fits this host, otherwise produce the distributed plan."""
    from .scale import (DeviceSpec, TransformerSpec, host_memory_available, host_training_bytes, parse_count, plan,
                        spec_for_params)
    n = parse_count(a.params)
    seq = a.seq or 64
    batch = a.batch or 8
    byte = bool(a.data) and (a.data.lower().endswith(".bin") or a.tokenizer == "byte")
    vocab = 256 if byte else (512 if a.data else 24)
    if a.data and a.data.lower().endswith(".bin") and Path(a.data).with_suffix(".json").exists():
        vocab = int(json.loads(Path(a.data).with_suffix(".json").read_text()).get("vocab", vocab))
    elif a.data and a.tokenizer not in ("char", "byte"):
        from .train.tokenizers import load_tokenizer
        vocab = load_tokenizer(a.tokenizer).vocab_size
    small = spec_for_params(n, vocab, seq)
    need, avail = host_training_bytes(small, batch), host_memory_available()
    if a.memory_gb:
        avail = int(a.memory_gb * 1e9 / 0.7)
    if a.lora_rank:
        big = spec_for_params(n, vocab, a.seq or 64)
        r = a.lora_rank
        adapters = big.layers * r * 2 * (big.d_model + big.d_ff) + r * (big.d_model + big.vocab)
        largest = 4 * max(big.vocab * big.d_model, big.d_model * big.d_ff)
        lora_need = 24 * adapters + 4 * largest + host_training_bytes(TransformerSpec("a", big.layers, big.d_model,
                                                                                       big.heads, big.d_ff, big.vocab,
                                                                                       big.seq), batch) * 0
        if not avail or lora_need <= 0.7 * avail:
            print(f"LoRA fine-tuning of a {big.params() / 1e9:.2f}B-parameter transformer (L={big.layers}, "
                  f"d={big.d_model}, heads={big.heads}): {adapters / 1e6:.1f}M trainable adapter parameters; the "
                  f"{big.params() / 1e9:.1f}B frozen base weights are regenerated from their seeds on every use "
                  f"(procedural base, not a pretrained model); host memory ~{lora_need / 1e9:.1f} GB")
            a.model = "transformer"
            a.overrides = {"seq": a.seq or 64, "d_model": big.d_model, "heads": big.heads, "d_ff": big.d_ff,
                           "layers": big.layers}
            if a.backend in ("functional", "cycle"):
                from .runtime.accel import torch_available
                a.backend = "accel" if torch_available() else "fast"
            a.arch = "target" if a.arch == "dev" else a.arch
            return None
    if avail and need <= 0.7 * avail:
        print(f"{n / 1e6:.1f}M parameters -> transformer L={small.layers} d={small.d_model} heads={small.heads}; "
              f"estimated host memory {need / 1e9:.1f} GB of {avail / 1e9:.1f} GB available: training numerically")
        a.model = "transformer"
        a.overrides = {"seq": seq, "d_model": small.d_model, "heads": small.heads, "d_ff": small.d_ff,
                       "layers": small.layers}
        if a.backend == "auto" or (a.backend == "functional" and n > 2e7):
            from .runtime.accel import torch_available
            a.backend = "accel" if torch_available() else "fast"
            print(f"using the {a.backend} backend (TITAN IR kernels) for this size; --backend functional forces "
                  "ISA-level execution")
        if a.arch == "dev" and n > 2e6:
            a.arch = "host"
        return None
    import shutil
    from .scale import offload_requirements
    seq_o = a.seq or 128
    big = spec_for_params(n, vocab, seq_o)
    req = offload_requirements(big, batch)
    if a.offload_dir:
        Path(a.offload_dir).mkdir(parents=True, exist_ok=True)
        free = shutil.disk_usage(a.offload_dir).free
        if req["storage_bytes"] <= 0.9 * free and (not avail or req["ram_bytes"] <= 0.8 * avail):
            print(f"{n / 1e9:.3g}B parameters exceed RAM; training with storage offload at {a.offload_dir}: needs "
                  f"~{req['storage_bytes'] / 1e9:,.0f} GB storage ({free / 1e9:,.0f} GB free) and "
                  f"~{req['ram_bytes'] / 1e9:.1f} GB RAM")
            a.model = "transformer"
            a.overrides = {"seq": seq_o, "d_model": big.d_model, "heads": big.heads, "d_ff": big.d_ff,
                           "layers": big.layers}
            a.backend = "fast"
            a.arch = "host" if a.arch == "dev" else a.arch
            return None
        print(f"Single-machine training of {n / 1e9:.3g}B parameters with storage offload needs "
              f"~{req['storage_bytes'] / 1e12:.2f} TB free storage and ~{req['ram_bytes'] / 1e9:.0f} GB RAM; "
              f"{a.offload_dir} has {free / 1e9:,.0f} GB free and this host {avail / 1e9:.0f} GB RAM.\n")
    else:
        print(f"A {n / 1e9:.3g}B-parameter model needs about {16 * big.params() / 1e12:.2f} TB for weights, "
              f"gradients and Adam states, more than this host's {avail / 1e9:.1f} GB RAM. It trains on ONE machine "
              f"with --offload-dir on storage with ~{req['storage_bytes'] / 1e12:.2f} TB free (and "
              f"~{req['ram_bytes'] / 1e9:.0f} GB RAM), or distributed. Exact accounting: "
              f"`titan plan --params {a.params} --single-machine`.\n")
    spec = spec_for_params(n, 50304, 2048)
    print("Distributed training plan on the TITAN-X1 target system:")
    dev = DeviceSpec.from_arch(load_config("target"))
    for d in (a.devices or [None]):
        r0 = plan(spec, dev, 1)
        nd = d or max(64, 1 << math.ceil(math.log2(r0["min_devices_for_model_states"])))
        _print_plan(plan(spec, dev, nd, 1024), "TITAN")
    print("\nmethod: analytical estimate (Mode C); run `titan plan --params ... --compare-b300` for details")
    return 0


def _parse_set(items) -> dict:
    out = {}
    for it in items:
        k, sep, v = it.partition("=")
        if not sep:
            raise SystemExit(f"--set expects KEY=VALUE, got {it!r}")
        low = v.lower()
        if low in ("true", "false"):
            out[k] = low == "true"
        else:
            try:
                out[k] = int(v)
            except ValueError:
                try:
                    out[k] = float(v)
                except ValueError:
                    out[k] = v
    return out


def cmd_quickstart(a) -> int:
    from .runtime import BACKENDS, backend_status
    from .train import PROFILES, TrainConfig, Trainer
    from .train.datasets import DATASETS
    a.overrides = {}
    if a.params:
        rc = _quickstart_params(a)
        if rc is not None:
            return rc
    if a.interactive:
        print("ROUGE TITAN QuickStart\n")
        a.model = _ask("1. model", sorted(PROFILES), a.model or "mlp")
        ds_opts = ["text"] if a.model == "transformer" else [d for d in sorted(DATASETS) if d != "text"]
        own = input("2. own data file (.csv/.npz/.npy/.txt, empty = built-in dataset): ").strip()
        if own:
            a.data = own
            if not own.lower().endswith((".txt", ".text", ".md")):
                a.target = input("   target column (empty = last column): ").strip() or None
        else:
            a.dataset = _ask("   built-in dataset", ds_opts, ds_opts[0] if a.dataset is None else a.dataset)
        a.profile = _ask("3. training profile", sorted(PROFILES[a.model]), a.profile)
        b = input(f"4. batch size (default {PROFILES[a.model][a.profile]['batch']}): ").strip()
        a.batch = int(b) if b else None
        a.precision = _ask("   precision", ["fp32", "bf16", "fp16"], a.precision)
        print("5. execution backend:")
        for bk, ok, why in backend_status():
            print(f"     {bk.key:10s} {'OK ' if ok else 'N/A'} {why}")
        a.backend = _ask("   backend", list(BACKENDS), a.backend)
        if input("6. QuickStart now? [Y/n]: ").strip().lower() in ("n", "no"):
            return 0
    if a.set:
        a.overrides = {**a.overrides, **_parse_set(a.set)}
    if a.model_config or a.model_file:
        a.model = "transformer"
    tc = TrainConfig(model=a.model, dataset=a.dataset, profile=a.profile, batch=a.batch, precision=a.precision,
                     backend=a.backend, steps=a.steps, lr=a.lr, optimizer=a.optimizer, seed=a.seed,
                     eval_every=a.eval_every, ckpt_every=a.ckpt_every, arch=a.arch, out_dir=a.out,
                     data=a.data, target=a.target, task=a.task, overrides=a.overrides, init_from=a.init_from,
                     freeze=a.freeze or [], tokenizer=a.tokenizer, schedule=a.schedule, weight_decay=a.weight_decay,
                     clip_grad=a.clip_grad, early_stop=a.early_stop, warmup=a.warmup,
                     offload_dir=a.offload_dir, offload_mb=a.offload_mb, init_scheme=a.init,
                     lora_rank=a.lora_rank, lora_alpha=a.lora_alpha, model_config=a.model_config,
                     torch_compile={"auto": None, "on": True, "off": False}[a.compile], accelerators=a.accelerators,
                     model_file=a.model_file)
    try:
        tr = Trainer(tc)
    except (RuntimeError, ValueError, FileNotFoundError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    if a.resume:
        tr.load_checkpoint(a.resume)
    s = tr.run()
    tr.close()
    print("\nSummary:")
    _print_kv({k: v for k, v in s.items() if k not in ("placement", "provenance")})
    print(f"\nexecuted on TITAN: {', '.join(s['placement']['titan'])}")
    print(f"executed on host : {', '.join(s['placement']['host'])}")
    print(f"run directory    : {tr.out}  (config.json, metrics.jsonl, log.txt, checkpoints/, summary.json)")
    return 0


# ------------------------------------------------------------------ environment / data

def cmd_env(a) -> int:
    from .envinfo import environment
    e = environment(a.path)
    h = e["host"]
    print(f"host        {h['cpu']} ({h['logical_cpus']} logical CPUs), Python {h['python']}, NumPy {h['numpy']}")
    print(f"RAM         {e['ram_available_gb']:.1f} GB available of {e['ram_total_gb']:.1f} GB")
    print(f"storage     {e['storage_free_gb']:.1f} GB free of {e['storage_total_gb']:.1f} GB at {e['storage_path']}")
    print(f"PyTorch     {e['torch'] or 'not installed (pip install torch) - enables the accel backend'}"
          + (f", {e['torch_threads']} threads" if e["torch"] else ""))
    for g in e["gpus"]:
        print(f"GPU {g['index']}       {g['name']}: {g['free_gb']:.1f} GB free of {g['memory_gb']:.1f} GB, "
              f"bf16 {'yes' if g['bf16'] else 'no'}")
    if not e["gpus"]:
        print("GPU         none detected")
    print(f"backend     recommended: {e['recommended_backend']}")
    print(f"max trainable parameters (estimate): host RAM {e['max_trainable_params_host_ram'] / 1e6:,.0f} M"
          + (f", single GPU {e['max_trainable_params_single_gpu'] / 1e6:,.0f} M" if e["gpus"] else ""))
    print(f"max corpus on storage: {e['max_corpus_tokens_on_storage'] / 1e9:,.1f} G byte tokens")
    print(e["note"])
    if a.json:
        Path(a.json).write_text(json.dumps(e, indent=2, default=str))
    return 0


def cmd_prepare_data(a) -> int:
    from .train.tokens import prepare_bytes, prepare_tokens
    if a.tokenizer == "byte":
        meta = prepare_bytes(a.inputs, a.out)
        kind = "byte"
    else:
        from .train.tokenizers import load_tokenizer
        tok = load_tokenizer(a.tokenizer)
        meta = prepare_tokens(a.inputs, a.out, tok)
        kind = f"{tok.kind} (vocab {tok.vocab_size:,}, {meta['dtype']})"
    print(f"wrote {a.out}: {meta['tokens']:,} {kind} tokens from {len(meta['sources'])} file(s), sha256 "
          f"{meta['sha256'][:16]}...; metadata {Path(a.out).with_suffix('.json')}")
    return 0


def _problems(path) -> list[dict]:
    from .train.sft import read_jsonl
    return [p for p in read_jsonl(path) if "prompt" in p and "answer" in p]


def _stops(a):
    return tuple(x.encode().decode("unicode_escape") for x in (a.stop or []))


def cmd_generate(a) -> int:
    from .infer import generator_for_run, solve
    from .infer.ttc import load_verifier
    n = a.n if a.strategy not in ("greedy", "sample") else 1
    gen = generator_for_run(a.run, batch=max(n, len(a.prompt)), tmax=a.tmax, backend=a.backend, ckpt=a.ckpt)
    import time as _t
    t0 = _t.perf_counter()
    res = solve(gen, a.prompt, a.strategy, a.n, max_new=a.max_new, temperature=a.temperature, top_k=a.top_k,
                top_p=a.top_p, stop=_stops(a), regex=a.answer_regex, verifier=load_verifier(a.verifier), seed=a.seed)
    dt = _t.perf_counter() - t0
    for p, r in zip(a.prompt, res):
        print(f"{p}{r['completion']}")
        extra = f" votes={r['votes']}" if "votes" in r else ""
        print(f"  [{a.strategy}, {r['candidates']} candidate(s), answer={r['answer']}{extra}]")
    toks = sum(r["tokens"] for r in res)
    print(f"{toks} tokens in {dt:.2f} s ({toks / dt:,.0f} tokens/s, {gen.backend} backend, "
          f"{'KV cache' if gen.cached else 'full-window recompute'})")
    return 0


def cmd_reason(a) -> int:
    from .infer import evaluate_problems, generator_for_run
    from .infer.ttc import load_verifier
    probs = _problems(a.data)[:a.limit or None]
    ver = load_verifier(a.verifier)
    rows = []
    for strat in a.strategy:
        n = 1 if strat in ("greedy", "sample") else a.n
        gen = generator_for_run(a.run, batch=max(a.batch, n), backend=a.backend, ckpt=a.ckpt)
        r = evaluate_problems(gen, probs, strat, a.n, max_new=a.max_new, temperature=a.temperature, top_p=a.top_p,
                              stop=_stops(a), regex=a.answer_regex, verifier=ver, seed=a.seed)
        rows.append({k: v for k, v in r.items() if k not in ("results", "correct")})
        print(f"{strat:17s} n={r['n']:<3d} accuracy {100 * r['accuracy']:5.1f}%  tokens {r['generated_tokens']:7d}  "
              f"{r['wall_s']:7.2f} s  {r['tokens_per_s'] or 0:9,.0f} tok/s")
    if a.out:
        Path(a.out).write_text(json.dumps(rows, indent=2))
    return 0


def cmd_rft(a) -> int:
    from .infer.rft import rejection_finetune
    from .infer.ttc import load_verifier
    probs = _problems(a.data)
    ev = _problems(a.eval_data) if a.eval_data else None
    rep = rejection_finetune(a.run, probs, ev, rounds=a.rounds, samples=a.samples, steps=a.steps, out=a.out,
                             temperature=a.temperature, max_new=a.max_new, stop=_stops(a), regex=a.answer_regex,
                             verifier=load_verifier(a.verifier), backend=a.backend, batch=a.batch, lr=a.lr,
                             seed=a.seed)
    print(json.dumps(rep, indent=2))
    return 0


def cmd_hardware(a) -> int:
    from .runtime.hardware import profile
    p = profile()
    c = p["cpu"]
    print(f"CPU   {c['model']}: {c['logical_cores']} logical cores, {c.get('ram_gb', '?')} GB RAM, "
          f"features {', '.join(c['flags']) or '-'}")
    for d in p["devices"]:
        m = p["measured"].get(d["device"], {})
        extra = f", {d['memory_gb']} GB, sm {d['capability']}" if "memory_gb" in d else ""
        print(f"{d['device']:7s} {d['name']}{extra}: FP32 GEMM {m.get('fp32_tflops', '?')} TFLOP/s"
              + (f", BF16 (exact, FP32 accumulate) {m['bf16_exact_tflops']} TFLOP/s" if "bf16_exact_tflops" in m else "")
              + f", copy {m.get('copy_gb_s', '?')} GB/s" + (f"  [{m['error']}]" if "error" in m else ""))
    r = p["recommended"]
    print(f"recommended: devices {r['devices']} ({'data parallel' if r['data_parallel'] else 'single device'}), "
          f"precision {r['precision']}, compile {r['compile']}; {r['gemm_tflops_total_best']} TFLOP/s GEMM in total "
          f"({r['vs_this_cpu_fp32']}x this CPU's FP32)")
    print(p["method"])
    if a.train_benchmark:
        print("training benchmark (same model and steps on this machine):")
        from .runtime.hardware import train_benchmark
        p["train_benchmark"] = tb = train_benchmark(a.steps)
        print("speed-up vs 1 device FP32:", tb["speedup_vs_1_device_fp32"])
    if a.json:
        Path(a.json).write_text(json.dumps(p, indent=2))
    return 0


def cmd_transplant(a) -> int:
    from .transplant import transplant
    layers = []
    for r in a.layers:
        src, _, span = r.partition(":")
        first, _, last = span.partition("-")
        layers.append((int(src), int(first), int(last or first)))
    tt = int(a.tokenizer) if a.tokenizer.isdigit() else a.tokenizer
    rep = transplant(a.donors, layers, a.calib, tt, a.out, a.heal_steps, a.full_steps, a.lr, a.batch,
                     a.calib_windows, backend=a.backend, seq=a.seq)
    print(json.dumps({k: rep[k] for k in ("vocab_transplant", "bridges", "bits_per_byte", "final_run")}, indent=2))
    return 0


def cmd_merge(a) -> int:
    from .merge import merge_cli
    return merge_cli(a)


def cmd_tokenizer_train(a) -> int:
    import time as _t
    from .train.tokenizers import BPETokenizer
    t0 = _t.perf_counter()
    texts = [Path(f).read_text(encoding="utf-8", errors="replace") for f in a.inputs]
    tok = BPETokenizer.train(texts, a.vocab, a.min_frequency)
    tok.save(a.out)
    n_chars = sum(len(t) for t in texts)
    n_tok = sum(len(tok.encode(t)) for t in texts)
    print(f"trained byte-level BPE: vocab {tok.vocab_size:,} ({len(tok.merges):,} merges) on {n_chars:,} characters "
          f"in {_t.perf_counter() - t0:.1f} s; {n_chars / max(1, n_tok):.2f} characters/token; wrote {a.out}")
    return 0


def cmd_tokenizer_info(a) -> int:
    from .train.tokenizers import load_tokenizer
    tok = load_tokenizer(a.spec, fit_text=a.text)
    ids = tok.encode(a.text)
    print(json.dumps({**tok.describe(), "fingerprint": tok.fingerprint[:16], "sample_ids": ids[:32],
                      "roundtrip": tok.decode(ids) == a.text}, default=str))
    return 0


# ------------------------------------------------------------------ large models

def _print_plan(r: dict, title: str) -> None:
    m, b = r["model"], r["best"]
    print(f"{title}: {m['name']} {m['params'] / 1e9:.2f}B params (L={m['layers']}, d={m['d_model']}, "
          f"heads={m['heads']}, seq={m['seq']}) on {r['devices']} x {r['device']['name']}, "
          f"global batch {r['global_batch']} sequences = {r['tokens_per_step']:,} tokens/step")
    if not b:
        print(f"  NOT FEASIBLE: model states alone need >= {r['min_devices_for_model_states']} devices "
              f"({r['plans_rejected_memory']} plans rejected for memory)")
        return
    t, mem = b["time_s"], b["memory_gb"]
    print(f"  best plan: TP={b['tp']} PP={b['pp']} DP={b['dp']} micro-batch={b['micro_batch']} ZeRO-{b['zero']} "
          f"recompute={'full' if b['recompute'] else 'off'}")
    print(f"  memory/device: {mem['total']:.1f} of {mem['capacity_usable']:.0f} GB (weights {mem['weights']:.1f}, "
          f"grads {mem['grads']:.1f}, optimizer {mem['optimizer']:.1f}, activations {mem['activations']:.1f})")
    print(f"  step time {t['step']:.3f} s (pipeline compute {t['pipeline_compute']:.3f}, DP comm "
          f"{t['data_parallel_comm']:.3f}, bubble {100 * t['pipeline_bubble_fraction']:.1f}%) -> "
          f"{b['tokens_per_s']:,.0f} tokens/s, MFU {100 * b['mfu']:.1f}%")


def cmd_plan(a) -> int:
    from .scale import DeviceSpec, Links, compare_devices, plan, preset, spec_for_params
    spec = preset(a.preset, a.vocab, a.seq) if a.preset else spec_for_params(a.params, a.vocab, a.seq)
    if a.single_machine:
        import time as _t
        from .scale import compile_training_program, execution_memory
        t0 = _t.perf_counter()
        exe = compile_training_program(spec, a.batch)
        n = sum(exe.buffers[p].shape[0] * exe.buffers[p].shape[1] for p in exe.params
                if not p.endswith((".adam_m", ".adam_v")))
        print(f"{spec.name}: complete training step (forward, loss, backward, clipping, AdamW) compiled to TITAN IR "
              f"in {_t.perf_counter() - t0:.1f} s: {n / 1e9:.2f}B parameters, {len(exe.module.kernels):,} kernels, "
              f"{len(exe.lazy_init):,} lazily initialized tensors (seq {spec.seq}, batch {a.batch})")
        for off in (None, a.offload_mb):
            m = execution_memory(exe, off)
            how = "in RAM" if off is None else f"with storage offload (tensors >= {off:g} MiB)"
            print(f"  {how:38s}: RAM {m['ram_bytes'] / 1e9:9.1f} GB   storage {m['storage_bytes'] / 1e9:9.1f} GB")
        print("method: exact accounting of the compiled kernel schedule (FP32 storage); "
              "run with `titan quickstart --params ... --offload-dir DIR` on a machine that meets it")
        return 0
    dev = DeviceSpec.from_arch(load_config(a.arch))
    links = Links(tp_gbps=a.tp_gbps, dp_gbps=a.dp_gbps, gemm_efficiency=a.gemm_eff)
    out = []
    for n in a.devices:
        if a.compare_b300:
            c = compare_devices(spec, dev, DeviceSpec.b300(), n, a.global_batch, links)
            _print_plan(c["a"], "TITAN")
            _print_plan(c["b"], "B300 ")
            if c["speedup_a_over_b"]:
                print(f"  -> TITAN / B300 step-time ratio: {c['speedup_a_over_b']:.2f}x (same model and assumptions)")
            out.append(c)
        else:
            r = plan(spec, dev, n, a.global_batch, links)
            _print_plan(r, "TITAN")
            out.append(r)
        print()
    print("method: analytical estimate (Mode C) with ASSUMED links "
          f"(TP {a.tp_gbps:g} GB/s, DP/PP {a.dp_gbps:g} GB/s) and GEMM efficiency {a.gemm_eff:g}; not a measurement")
    if a.out:
        Path(a.out).write_text(json.dumps(out, indent=2, default=str))
    return 0


# ------------------------------------------------------------------ vertical slice

def cmd_matmul(a) -> int:
    from .compiler import CompileOptions, Graph, compile_graph, run_reference
    from .isa import disassemble
    from .perf.analytical import gemm_roofline
    from .runtime import Device
    cfg = load_config(a.arch)
    dt = DType.parse(a.dtype)
    g = Graph("matmul")
    x, w = g.input("a", (a.m, a.k), dt), g.input("b", (a.k, a.n), dt)
    g.output("c", g.matmul(x, w))
    exe = compile_graph(g, cfg, CompileOptions(gemm_macro=a.macro))
    print("== TITAN IR ==")
    print(exe.module.dump())
    print(f"\n== TITAN ISA ({len(exe.program)} instructions; first {min(a.show, len(exe.program))}) ==")
    for ins in exe.program.instructions[:a.show]:
        print("  " + disassemble(ins))
    rng = np.random.default_rng(a.seed)
    if dt.is_int:
        lim = 8 if dt == DType.INT4 else 128
        feeds = {"a": rng.integers(-lim, lim, (a.m, a.k)), "b": rng.integers(-lim, lim, (a.k, a.n))}
    else:
        feeds = {"a": rng.standard_normal((a.m, a.k)), "b": rng.standard_normal((a.k, a.n))}
    ref, _ = run_reference(g, feeds)
    report = {"workload": f"C[{a.m}x{a.n}] = A[{a.m}x{a.k}] @ B[{a.k}x{a.n}]", "precision": dt.name,
              "config": cfg.name}
    for mode in ("functional", "cycle"):
        out = Device(cfg).run(exe, feeds, mode)
        err = float(np.abs(out.outputs["c"].astype(np.float64) - ref["c"]).max())
        r = out.result.summary()
        r["max_abs_error_vs_reference"] = err
        report[mode] = r
    if a.rtl:
        from .rtl.cosim import MXUTileSim, make_matmul_hook
        if not dt.is_int:
            print("error: the RTL backend implements the INT8/INT4 matrix engine only", file=sys.stderr)
            return 2
        hook = make_matmul_hook(MXUTileSim(8, 8, 8))
        out = Device(cfg).run(exe, feeds, "functional", matmul_hook=hook)
        report["rtl_cosim"] = {"bit_exact_vs_reference": bool(np.array_equal(out.outputs["c"], ref["c"])),
                               "matmuls_on_rtl": hook.stats.get("rtl_matmuls", 0),
                               "method": "MATMUL executed by the Verilator model of rtl/titan_mxu_tile.sv; "
                                         "DMA/control in the functional model"}
    report["analytical"] = gemm_roofline(cfg, a.m, a.n, a.k, dt)
    print("\n== results (modes are reported separately) ==")
    print(json.dumps(report, indent=2, default=float))
    ok = report["functional"]["max_abs_error_vs_reference"] <= (0 if dt.is_int else 1e-3 * max(1, a.k ** 0.5))
    ok = ok and report.get("rtl_cosim", {}).get("bit_exact_vs_reference", True)
    print("\nVERIFICATION:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


# ------------------------------------------------------------------ performance

def cmd_bench(a) -> int:
    from .perf.benchmark import run_suite, write_report
    res = run_suite(a.suite, a.arch, a.seed)
    jp, mp = write_report(res, a.out)
    print(f"\nreport: {mp}\nraw data: {jp}")
    return 0 if all(r["verification"]["passed"] for r in res["records"]) else 1


def cmd_tune(a) -> int:
    from .tune import tune_gemm
    cfg = load_config(a.arch)
    r = tune_gemm(cfg, a.m, a.n, a.k, DType.parse(a.dtype), a.seed, a.candidates, log=print if a.verbose else None)
    best = r["best"]
    print(f"{r['workload']} on {cfg.name}: baseline {r['baseline']['cycles']:.0f} simulated cycles")
    if best:
        print(f"best verified candidate: {best['cycles']:.0f} cycles, options {best['options']}")
    print(f"speed-up vs baseline: {r['speedup_vs_baseline']:.3f}x  ({r['candidates_evaluated']} evaluated, "
          f"{r['candidates_rejected']} rejected)  method: {r['method']}")
    if a.out:
        Path(a.out).write_text(json.dumps(r, indent=2, default=str))
    return 0


# ------------------------------------------------------------------ multi-chip

def cmd_scale(a) -> int:
    from .multichip import scaling_study
    r = scaling_study(tuple(a.devices), a.topology, a.arch, a.global_batch, tuple(a.hidden),
                      chiplets_per_package=a.chiplets, link_gbps=a.link_gbps, latency_us=a.latency_us)
    print(r["workload"], "on", r["arch"])
    print(f"{'devices':>7} {'system':>22} {'compute us':>11} {'comm us':>9} {'step us':>9} {'speedup':>8} "
          f"{'efficiency':>10} {'comm %':>7}")
    for x in r["rows"]:
        print(f"{x['devices']:>7} {x['system']:>22} {x['sim_compute_s'] * 1e6:>11.2f} {x['model_comm_s'] * 1e6:>9.2f} "
              f"{x['step_s'] * 1e6:>9.2f} {x['speedup']:>8.2f} {100 * x['efficiency']:>9.1f}% "
              f"{100 * x['comm_fraction']:>6.1f}%")
    print("method:", r["method"])
    if a.out:
        Path(a.out).write_text(json.dumps(r, indent=2, default=str))
    return 0


def cmd_dp_train(a) -> int:
    from .multichip import DataParallelTrainer
    tr = DataParallelTrainer(a.devices, arch=a.arch, dataset=a.dataset, global_batch=a.global_batch, lr=a.lr,
                             seed=a.seed, mode=a.mode)
    for i in range(a.steps):
        r = tr.step()
        if not r["replicas_identical"]:
            print(f"error: replicas diverged at step {i}", file=sys.stderr)
            return 1
        if (i + 1) % max(1, a.steps // 5) == 0:
            msg = f"step {i + 1:4d} loss {r['loss']:.4f} replicas identical"
            if "step_s" in r:
                msg += (f" | simulated step {r['step_s'] * 1e6:.1f} us (compute {r['sim_compute_s'] * 1e6:.1f}, "
                        f"all-reduce {r['model_comm_s'] * 1e6:.1f} modelled)")
            print(msg)
    print(f"eval accuracy (device 0): {tr.evaluate():.3f}   devices={a.devices} system={tr.sys.name}")
    return 0


# ------------------------------------------------------------------ RTL

def cmd_rtl_verify(a) -> int:
    from .rtl.cosim import correspondence_test
    rc = 0
    for dw in a.data_w:
        r = correspondence_test(a.cases, a.seed, a.rows, a.cols, dw)
        print(f"INT{dw} {r['tile']} tile: {r['cases']} random MATMUL cases, {r['mismatches']} mismatches, "
              f"{r['rtl_jobs']} RTL jobs, {r['rtl_cycles']} RTL cycles  [{r['simulator']}]")
        rc |= r["mismatches"] != 0
    print("method: RTL co-simulation (Verilator) vs TITAN functional golden model, bit-exact comparison")
    return int(rc)


def cmd_synth(a) -> int:
    from .rtl.synth import synthesize, yosys_version
    rows = []
    for top, params in (("rtl_mac_array", {}), ("titan_mxu_tile", {"ROWS": 4, "COLS": 4, "DATA_W": 8}),
                        ("titan_mxu_tile", {"ROWS": 8, "COLS": 8, "DATA_W": 8}),
                        ("titan_mxu_tile", {"ROWS": 8, "COLS": 8, "DATA_W": 4})):
        for target in a.targets:
            r = synthesize(top, params, target, a.out)
            rows.append(r)
            print(f"{top:15s} {str(params):40s} {target:8s} cells={r['total_cells']:6d} {r.get('summary', '')}")
    pnr = []
    if a.pnr:
        from .rtl.synth import place_and_route_ecp5
        for params, dev in (({"ROWS": 4, "COLS": 4, "DATA_W": 8}, "25k"), ({"ROWS": 8, "COLS": 8, "DATA_W": 8}, "85k"),
                            ({"ROWS": 8, "COLS": 8, "DATA_W": 4}, "85k")):
            r = place_and_route_ecp5("titan_mxu_tile", params, dev, out_dir=a.out)
            pnr.append(r)
            print(f"P&R titan_mxu_tile {params} on {r['device']}: {r['status']} "
                  f"Fmax(STA) {r.get('fmax_mhz')} util {r.get('utilization', r.get('reason'))}")
    if a.out:
        out = Path(a.out)
        (out / "synth_summary.json").write_text(json.dumps({"tool": yosys_version(), "results": rows,
                                                            "place_and_route": pnr}, indent=2))
        print(f"logs and summary in {out}")
    print("method: Yosys synthesis + technology mapping (cell counts, pre-place-and-route)" +
          ("; nextpnr-ecp5 out-of-context P&R, Fmax = post-route static timing estimate" if a.pnr else "") +
          ". No power figures and no FPGA measurement.")
    return 0


# ------------------------------------------------------------------ assembler

def cmd_asm(a) -> int:
    from .emu import Machine, run
    from .isa import assemble, encode_program
    prog = assemble(Path(a.file).read_text())
    cfg = load_config(a.arch)
    prog.validate(cfg)
    print(f"assembled {len(prog)} instructions, {len(prog.kernels)} kernels: valid for {cfg.name}")
    if a.out:
        Path(a.out).write_bytes(encode_program(prog))
        print(f"wrote {a.out}")
    if a.run:
        r = run(Machine(cfg), prog, a.mode)
        print(json.dumps(r.summary(), indent=2))
    return 0


def cmd_disasm(a) -> int:
    from .isa import decode_program, disassemble_program
    print(disassemble_program(decode_program(Path(a.file).read_bytes())), end="")
    return 0


# ------------------------------------------------------------------ main

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="titan", description="ROUGE TITAN / TITAN-X1 virtual accelerator toolkit")
    sub = p.add_subparsers(dest="cmd", required=True)
    arch_help = f"architecture preset {list_presets()} or TOML path"

    s = sub.add_parser("info", help="architecture summary")
    s.add_argument("--arch", default="dev", help=arch_help)
    s.set_defaults(fn=cmd_info)

    s = sub.add_parser("backends", help="list execution backends")
    s.set_defaults(fn=cmd_backends)

    s = sub.add_parser("quickstart", help="train a model on the virtual accelerator")
    s.add_argument("--model", default=None, choices=["mlp", "transformer"],
                   help="default: transformer for text data, otherwise mlp")
    s.add_argument("--dataset", default=None, help="built-in dataset: spirals, blobs, xor, digits, text")
    s.add_argument("--data", default=None, help="your own data: .csv/.tsv/.npz/.npy (tabular) or .txt (text)")
    s.add_argument("--target", default=None, help="target column name or index (default: last column)")
    s.add_argument("--task", default="auto", choices=["auto", "classification", "regression"])
    s.add_argument("--params", default=None, help="size a transformer by parameter count, e.g. 20m, 100m, 100b "
                                                   "(trains if it fits this host, otherwise plans it on TITAN-X1 target)")
    s.add_argument("--seq", type=int, default=None, help="sequence length for --params")
    s.add_argument("--devices", type=int, nargs="+", default=None, help="devices for the distributed plan")
    s.add_argument("--memory-gb", type=float, default=None, help="RAM budget for --params (default: 70%% of available)")
    s.add_argument("--init-from", default=None, help="fine-tune: start from this checkpoint's weights")
    s.add_argument("--freeze", nargs="+", default=None, help="fine-tune: parameter prefixes/globs to keep fixed")
    s.add_argument("--tokenizer", default="char",
                   help="tokenizer for .txt data: char | byte | titan-bpe.json (titan tokenizer train) | Hugging Face "
                        "tokenizer.json | SentencePiece .model | file.py:Factory")
    s.add_argument("--model-config", default=None,
                   help="your transformer architecture (JSON/TOML): norm, activation, position, heads, kv_heads, "
                        "d_model, d_ff, layers, seq, tie_embeddings, bias, prenorm, ... (docs/CUSTOMIZE.md)")
    s.add_argument("--model-file", default=None,
                   help="your own model code: file.py:factory or package.module:factory (docs/CUSTOMIZE.md)")
    s.add_argument("--set", nargs="+", default=None, metavar="KEY=VALUE",
                   help="architecture settings, e.g. --set norm=rmsnorm activation=swiglu position=rope kv_heads=2")
    s.add_argument("--schedule", default=None, choices=["constant", "cosine"])
    s.add_argument("--warmup", type=int, default=None)
    s.add_argument("--weight-decay", type=float, default=None)
    s.add_argument("--clip-grad", type=float, default=None)
    s.add_argument("--early-stop", type=int, default=0, help="stop after N evaluations without improvement")
    s.add_argument("--offload-dir", default=None,
                   help="storage (NVMe/SSD) for weights, optimizer state and large temporaries: model size is then "
                        "limited by storage instead of RAM")
    s.add_argument("--offload-mb", type=float, default=4.0, help="offload tensors of at least this many MiB")
    s.add_argument("--lora-rank", type=int, default=0,
                   help="LoRA fine-tuning: train rank-R adapters, base weights frozen (regenerated, never stored)")
    s.add_argument("--lora-alpha", type=float, default=16.0)
    s.add_argument("--compile", default="auto", choices=["auto", "on", "off"],
                   help="accel: torch.compile the training program (one-time compile of ~0.5-2 min, then faster "
                        "steps); auto: on when the run's measured remaining time exceeds 10 min")
    s.add_argument("--init", default="auto", choices=["auto", "xavier", "gpt2"],
                   help="weight initialization (auto: GPT-2 scheme for transformers with d_model >= 256)")
    s.add_argument("--profile", default="small", choices=["tiny", "small", "medium"])
    s.add_argument("--batch", type=int, default=None)
    s.add_argument("--precision", default="auto", choices=["auto", "fp32", "bf16", "fp16"],
                   help="auto: bf16 for d_model >= 256 where the exact BF16 GEMM path exists (AMX/CUDA), else fp32")
    s.add_argument("--accelerators", default="auto",
                   help="data parallel over connected devices: auto (all GPUs if >= 2) | N | cuda:0,cuda:1")
    s.add_argument("--backend", default="auto",
                   choices=["functional", "fast", "accel", "auto", "cycle", "rtl", "fpga", "hardware"],
                   help="auto (default): fastest executor for this host (accel on a GPU or for d_model >= 128, "
                        "else fast); fast: the compiled TITAN program as one NumPy function; accel: the same on "
                        "GPU/CPU via PyTorch; functional: every TITAN instruction (ISA level, bit-exact replay); "
                        "cycle: + simulated timing")
    s.add_argument("--steps", type=int, default=None)
    s.add_argument("--lr", type=float, default=None)
    s.add_argument("--optimizer", default="adam", choices=["adam", "sgd"])
    s.add_argument("--seed", type=int, default=0)
    s.add_argument("--eval-every", type=int, default=50)
    s.add_argument("--ckpt-every", type=int, default=100)
    s.add_argument("--arch", default="dev", help=arch_help)
    s.add_argument("--out", default=None, help="run directory")
    s.add_argument("--resume", default=None, help="checkpoint .npz to resume from")
    s.add_argument("-i", "--interactive", action="store_true", help="guided selection")
    s.set_defaults(fn=cmd_quickstart)

    s = sub.add_parser("env", help="inspect this environment (CPU, RAM, storage, GPUs) and its training limits")
    s.add_argument("--path", default=".", help="storage location for data and runs")
    s.add_argument("--json", default=None)
    s.set_defaults(fn=cmd_env)

    s = sub.add_parser("prepare-data", help="stream text files into a memory-mapped token corpus for pretraining")
    s.add_argument("inputs", nargs="+")
    s.add_argument("--out", required=True)
    s.add_argument("--tokenizer", default="byte", help="byte (default) or any tokenizer spec (see quickstart)")
    s.set_defaults(fn=cmd_prepare_data)

    def gen_args(s, n_default=8):
        s.add_argument("--backend", default="auto", choices=["auto", "fast", "accel"])
        s.add_argument("--ckpt", default=None, help="checkpoint .npz (default: best, else latest)")
        s.add_argument("--max-new", type=int, default=64)
        s.add_argument("--temperature", type=float, default=0.8)
        s.add_argument("--top-k", type=int, default=0)
        s.add_argument("--top-p", type=float, default=1.0)
        s.add_argument("--n", type=int, default=n_default, help="samples / beam width for test-time compute")
        s.add_argument("--stop", nargs="*", default=["\\n"], help="stop strings (escapes allowed)")
        s.add_argument("--answer-regex", default=None, help="answer extraction (default: last number)")
        s.add_argument("--verifier", default=None, help="file.py:fn(prompt, completion) -> score (best-of-n, rft)")
        s.add_argument("--seed", type=int, default=0)

    s = sub.add_parser("generate", help="generate text from a training run (KV cache, sampling, beam, TTC)")
    s.add_argument("run")
    s.add_argument("--prompt", nargs="+", required=True)
    s.add_argument("--strategy", default="sample", choices=["greedy", "sample", "best-of-n", "self-consistency", "beam"])
    s.add_argument("--tmax", type=int, default=None, help="cache length (default: trained sequence length)")
    gen_args(s, 4)
    s.set_defaults(fn=cmd_generate)

    s = sub.add_parser("reason", help="accuracy vs test-time compute on {prompt, answer} problems (JSONL)")
    s.add_argument("run")
    s.add_argument("--data", required=True)
    s.add_argument("--strategy", nargs="+", default=["greedy", "self-consistency", "best-of-n"])
    s.add_argument("--limit", type=int, default=0)
    s.add_argument("--batch", type=int, default=64, help="generation rows (problems x samples per step)")
    s.add_argument("--out", default=None)
    gen_args(s)
    s.set_defaults(fn=cmd_reason)

    s = sub.add_parser("rft", help="reasoning post-training: rejection sampling fine-tuning (STaR)")
    s.add_argument("run")
    s.add_argument("--data", required=True, help="training problems {prompt, answer} (JSONL)")
    s.add_argument("--eval-data", default=None, help="held-out problems for accuracy before/after")
    s.add_argument("--rounds", type=int, default=2)
    s.add_argument("--samples", type=int, default=8)
    s.add_argument("--steps", type=int, default=300)
    s.add_argument("--lr", type=float, default=1e-3)
    s.add_argument("--batch", type=int, default=64)
    s.add_argument("--out", default="runs/rft")
    gen_args(s)
    s.set_defaults(fn=cmd_rft)

    s = sub.add_parser("merge", help="Frankenstein models: soup, SLERP, task arithmetic, TIES, layer stacking, MoE upcycling")
    s.add_argument("method", choices=["average", "slerp", "task-arithmetic", "ties", "stack", "upcycle-moe"])
    s.add_argument("--models", nargs="+", required=True, help="run directories or checkpoint .npz files")
    s.add_argument("--base", default=None, help="base model for task-arithmetic / ties")
    s.add_argument("--weights", type=float, nargs="+", default=None, help="average: per-model weights")
    s.add_argument("--t", type=float, default=0.5, help="slerp interpolation")
    s.add_argument("--scale", type=float, default=1.0, help="task-arithmetic / ties: lambda")
    s.add_argument("--density", type=float, default=0.2, help="ties: fraction of each task vector kept")
    s.add_argument("--layers", nargs="+", default=None,
                   help="stack: SOURCE:FIRST-LAST ranges in order, e.g. 0:0-5 1:2-7 (SOURCE = index in --models)")
    s.add_argument("--experts", type=int, default=4, help="upcycle-moe: experts per MLP")
    s.add_argument("--top-k", type=int, default=2, help="upcycle-moe: experts per token")
    s.add_argument("--noise", type=float, default=0.0, help="upcycle-moe: relative noise to break expert symmetry")
    s.add_argument("--seed", type=int, default=0)
    s.add_argument("--out", required=True, help="output checkpoint .npz (+ .json, .model.json)")
    s.set_defaults(fn=cmd_merge)

    s = sub.add_parser("hardware", help="discover and measure connected compute (CPU/AMX, CUDA, XPU, MPS) "
                                        "and print the fastest TITAN configuration")
    s.add_argument("--json", default=None)
    s.add_argument("--train-benchmark", action="store_true",
                   help="also measure training: 1 device vs all connected accelerators, FP32 vs precision auto")
    s.add_argument("--steps", type=int, default=30)
    s.set_defaults(fn=cmd_hardware)

    s = sub.add_parser("transplant", help="Frankenstein transplant: donors with different tokenizers/widths, "
                                          "least-squares bridges, healing, bits-per-byte report")
    s.add_argument("--donors", nargs="+", required=True, help="donor run directories")
    s.add_argument("--layers", nargs="+", required=True, help="DONOR:FIRST-LAST blocks in model order, e.g. 0:0-3 1:2-5")
    s.add_argument("--calib", required=True, help="calibration / healing text (.txt); last 10%% is held out")
    s.add_argument("--tokenizer", default="0", help="target tokenizer: donor index or any tokenizer spec")
    s.add_argument("--heal-steps", type=int, default=300, help="phase 1: train the bridges only")
    s.add_argument("--full-steps", type=int, default=0, help="phase 2: train everything (lr / 3)")
    s.add_argument("--lr", type=float, default=3e-3)
    s.add_argument("--batch", type=int, default=8)
    s.add_argument("--calib-windows", type=int, default=64)
    s.add_argument("--seq", type=int, default=None)
    s.add_argument("--backend", default="auto", choices=["auto", "fast", "accel", "functional"])
    s.add_argument("--out", required=True)
    s.set_defaults(fn=cmd_transplant)

    s = sub.add_parser("tokenizer", help="train or inspect tokenizers")
    tsub = s.add_subparsers(dest="tcmd", required=True)
    t = tsub.add_parser("train", help="train a byte-level BPE tokenizer on your text")
    t.add_argument("inputs", nargs="+")
    t.add_argument("--vocab", type=int, default=4096)
    t.add_argument("--min-frequency", type=int, default=2)
    t.add_argument("--out", required=True)
    t.set_defaults(fn=cmd_tokenizer_train)
    t = tsub.add_parser("info", help="load any tokenizer spec and encode a sample")
    t.add_argument("spec")
    t.add_argument("--text", default="Hello TITAN.")
    t.set_defaults(fn=cmd_tokenizer_info)

    s = sub.add_parser("plan", help="distributed training plan for large models (up to 100B+ parameters)")
    g_ = s.add_mutually_exclusive_group()
    g_.add_argument("--params", default="100b", help="parameter count, e.g. 7b, 70b, 100b")
    g_.add_argument("--preset", default=None, help="gpt-125m ... gpt-175b")
    s.add_argument("--devices", type=int, nargs="+", default=[8, 64, 256])
    s.add_argument("--global-batch", type=int, default=1024, help="sequences per step")
    s.add_argument("--seq", type=int, default=2048)
    s.add_argument("--vocab", type=int, default=50304)
    s.add_argument("--arch", default="target", help=arch_help)
    s.add_argument("--compare-b300", action="store_true", help="apply the same model to NVIDIA B300")
    s.add_argument("--single-machine", action="store_true",
                   help="compile the full training step and report exact RAM/storage for one machine")
    s.add_argument("--batch", type=int, default=1, help="sequences per step for --single-machine")
    s.add_argument("--offload-mb", type=float, default=4.0)
    s.add_argument("--tp-gbps", type=float, default=900.0, help="ASSUMED tensor-parallel link bandwidth")
    s.add_argument("--dp-gbps", type=float, default=400.0, help="ASSUMED data/pipeline-parallel link bandwidth")
    s.add_argument("--gemm-eff", type=float, default=0.8, help="ASSUMED achievable GEMM efficiency")
    s.add_argument("--out", default=None)
    s.set_defaults(fn=cmd_plan)

    s = sub.add_parser("matmul", help="vertical slice: compile and execute one matrix multiplication")
    s.add_argument("--m", type=int, default=64)
    s.add_argument("--n", type=int, default=64)
    s.add_argument("--k", type=int, default=64)
    s.add_argument("--dtype", default="fp32")
    s.add_argument("--arch", default="dev", help=arch_help)
    s.add_argument("--macro", action="store_true", help="lower to the GEMM macro instruction")
    s.add_argument("--rtl", action="store_true", help="also execute MATMULs on the Verilator RTL model (INT8/INT4)")
    s.add_argument("--show", type=int, default=12, help="instructions to print")
    s.add_argument("--seed", type=int, default=0)
    s.set_defaults(fn=cmd_matmul)

    s = sub.add_parser("bench", help="run the reproducible benchmark suite")
    s.add_argument("--suite", default="quick", choices=["quick", "default"])
    s.add_argument("--arch", default="dev", help=arch_help)
    s.add_argument("--seed", type=int, default=0)
    s.add_argument("--out", default="reports")
    s.set_defaults(fn=cmd_bench)

    s = sub.add_parser("tune", help="verified GEMM tiling/scheduling search vs baseline")
    s.add_argument("--m", type=int, default=256)
    s.add_argument("--n", type=int, default=256)
    s.add_argument("--k", type=int, default=256)
    s.add_argument("--dtype", default="bf16")
    s.add_argument("--arch", default="dev", help=arch_help)
    s.add_argument("--candidates", type=int, default=48)
    s.add_argument("--seed", type=int, default=0)
    s.add_argument("--out", default=None)
    s.add_argument("-v", "--verbose", action="store_true")
    s.set_defaults(fn=cmd_tune)

    s = sub.add_parser("scale", help="multi-device strong-scaling study (cycle model + link model)")
    s.add_argument("--devices", type=int, nargs="+", default=[1, 2, 4, 8, 16])
    s.add_argument("--topology", default="ring", choices=["ring", "fully_connected", "mesh2d", "switch"])
    s.add_argument("--chiplets", type=int, default=0, help="chiplets per package (hierarchical system)")
    s.add_argument("--link-gbps", type=float, default=900.0, help="ASSUMED inter-package link bandwidth")
    s.add_argument("--latency-us", type=float, default=2.0, help="ASSUMED per-hop latency")
    s.add_argument("--global-batch", type=int, default=256)
    s.add_argument("--hidden", type=int, nargs="+", default=[256, 256])
    s.add_argument("--arch", default="dev", help=arch_help)
    s.add_argument("--out", default=None)
    s.set_defaults(fn=cmd_scale)

    s = sub.add_parser("dp-train", help="data-parallel training over N virtual devices")
    s.add_argument("--devices", type=int, default=4)
    s.add_argument("--steps", type=int, default=100)
    s.add_argument("--global-batch", type=int, default=64)
    s.add_argument("--lr", type=float, default=0.05)
    s.add_argument("--dataset", default="spirals")
    s.add_argument("--mode", default="cycle", choices=["functional", "cycle"])
    s.add_argument("--arch", default="dev", help=arch_help)
    s.add_argument("--seed", type=int, default=0)
    s.set_defaults(fn=cmd_dp_train)

    s = sub.add_parser("rtl-verify", help="RTL vs emulator correspondence (Verilator)")
    s.add_argument("--cases", type=int, default=20)
    s.add_argument("--seed", type=int, default=0)
    s.add_argument("--rows", type=int, default=8)
    s.add_argument("--cols", type=int, default=8)
    s.add_argument("--data-w", type=int, nargs="+", default=[8, 4])
    s.set_defaults(fn=cmd_rtl_verify)

    s = sub.add_parser("synth", help="Yosys resource estimates for the RTL")
    s.add_argument("--targets", nargs="+", default=["generic", "xc7", "ecp5"])
    s.add_argument("--pnr", action="store_true", help="also place & route on Lattice ECP5 with nextpnr")
    s.add_argument("--out", default="reports/synth")
    s.set_defaults(fn=cmd_synth)

    s = sub.add_parser("asm", help="assemble a TITAN assembly file")
    s.add_argument("file")
    s.add_argument("--arch", default="dev", help=arch_help)
    s.add_argument("--out", default=None, help="write binary program")
    s.add_argument("--run", action="store_true")
    s.add_argument("--mode", default="functional", choices=["functional", "cycle"])
    s.set_defaults(fn=cmd_asm)

    s = sub.add_parser("disasm", help="disassemble a TITAN binary")
    s.add_argument("file")
    s.set_defaults(fn=cmd_disasm)
    return p


def main(argv=None) -> int:
    p = build_parser()
    a = p.parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
